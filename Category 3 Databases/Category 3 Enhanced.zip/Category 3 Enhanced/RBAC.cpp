# ===========================
# File: src/RBAC.cpp
# ===========================
// (Intentionally empty — header-only helpers retained for clarity)